import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

// https://vite.dev/config/
export default defineConfig({
  plugins: [
    tailwindcss(),
    react()
  ],
  server: {
    port: 3000,
    open: false
  },
  optimizeDeps: {
    entries: ['index.html'],
    include: ['pdf-lib', 'xlsx', 'idb', 'lucide-react', 'canvas-confetti', 'ag-psd', 'prismjs']
  }
})
